# Kush Gudhka - Sparx banking
TSF(The Sparks Foundation) Internship Project : Basic Banking System 


Flow of this whole Website: Home Page > View all Users > Select and View one User > Transfer Money > Select reciever > View all Users > View Transfer History.


Database contains two Tables- Users Table & Transaction Table 
1. User table have basic fields such as name, email & current balance. 
2. Transaction table records all transfers happened along with their time.  

Stack used - 
Front-end : HTML, CSS, Bootstrap & Javascript 
Back-end : PHP 
Database : MySQL   

