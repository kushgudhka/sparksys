<!-- navbar --> 

      <nav class="navbar navbar-expand-md navbar-light bg-light">
      <a class="navbar-brand" href="index.php" style="color: rgb(34,193,195); font-style: italic; "><b>Sparx Banking</b></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php" style="color : #9ACD32; font-style: italic;"><b>home</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="createuser.php" style="color : #22E4AC; font-style: italic;"><b>create user</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transfermoney.php" style="color : #14C9CB; font-style: italic;"><b>transfer money</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transactionhistory.php" style="color : #08B3E5; font-style: italic;"><b>transaction history</b></a>
              </li>
          </div>
       </nav>
